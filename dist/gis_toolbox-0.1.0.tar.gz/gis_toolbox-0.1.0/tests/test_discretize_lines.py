import pytest
import geopandas as gpd
import numpy as np
from shapely.geometry import LineString, MultiLineString, Point
from gis_toolbox.modules.discretize_lines import (
    discretize_line_with_normal_vector,
    Config, OutputConfig,
)
from gis_toolbox.enums import GeometryType

@pytest.fixture
def empty_gdf():
    """
    Returns an empty GeoDataFrame.
    """
    return gpd.GeoDataFrame(geometry=[], crs="EPSG:4326")

@pytest.fixture
def simple_line_gdf():
    """
    Returns a GeoDataFrame with a single LineString 
    that spans from (0,0) to (10,0).
    """
    line = LineString([(0, 0), (10, 0)])
    return gpd.GeoDataFrame(geometry=[line], crs="EPSG:4326")

@pytest.fixture
def multi_segment_line_gdf():
    """
    Returns a GeoDataFrame with a single LineString 
    that has multiple vertices: (0,0)->(10,0)->(10,10).
    This yields 2 segments: 
        Segment 1: (0,0)->(10,0)
        Segment 2: (10,0)->(10,10)
    """
    line = LineString([(0, 0), (10, 0), (10, 10)])
    return gpd.GeoDataFrame(geometry=[line], crs="EPSG:4326")

@pytest.fixture
def multi_line_string_gdf():
    """
    Returns a GeoDataFrame with 1 MultiLineString 
    containing 2 separate lines:
      1) (0,0)->(10,0)
      2) (0,10)->(0,0)
    """
    mls = MultiLineString([
        LineString([(0, 0), (10, 0)]),
        LineString([(0, 10), (0, 0)])
    ])
    return gpd.GeoDataFrame(geometry=[mls], crs="EPSG:4326")

@pytest.fixture
def mix_lines_gdf():
    """
    Returns a GeoDataFrame with multiple features:
     1) A short line (maybe 5 units)
     2) A longer line
     3) A MultiLineString
     4) A near-degenerate line
    """
    line1 = LineString([(0, 0), (5, 0)])
    line2 = LineString([(0, 0), (0, 10)])
    mls   = MultiLineString([
        LineString([(1,1), (2,2)]),
        LineString([(2,2), (2,3)])
    ])
    degenerate = LineString([(0,0), (0,0)])  # zero-length

    return gpd.GeoDataFrame(geometry=[line1, line2, mls, degenerate], crs="EPSG:4326")


def test_empty_gdf(empty_gdf):
    """
    Test that an empty GeoDataFrame returns empty results and logs an error.
    """
    result = discretize_line_with_normal_vector(empty_gdf)
    assert len(result) == 0
    assert list(result.columns) == [] or OutputConfig.ROW_IDX_COL in result.columns
    # By default, we expect an empty GDF with no geometry or columns.

def test_simple_line_gdf(simple_line_gdf):
    """
    Test a single horizontal LineString from (0,0)->(10,0).
    """
    spacing = 2.0
    result = discretize_line_with_normal_vector(
        gdf_lines=simple_line_gdf, 
        discretization_distance=spacing
    )
    # The line is 10 units. With spacing=2, we expect 6 points: 0,2,4,6,8,10
    # But the actual code might add 1 more if rounding is used
    expected_pts = int(np.ceil(10.0 / spacing)) + 1
    assert len(result) == expected_pts, f"Expected {expected_pts} points, got {len(result)}"
    # Check columns
    for col in [
        OutputConfig.ROW_IDX_COL, 
        OutputConfig.SUB_IDX_COL, 
        OutputConfig.CHAINAGE_COL, 
        OutputConfig.NORMAL_X_COL, 
        OutputConfig.NORMAL_Y_COL, 
        "geometry"
    ]:
        assert col in result.columns, f"Missing column {col}"
    # Check the geometry type
    assert all(g.geom_type == "Point" for g in result.geometry), "All outputs must be points"
    # Check that CRS is preserved
    assert result.crs == simple_line_gdf.crs, "CRS should match input"

def test_multi_segment_line_gdf(multi_segment_line_gdf):
    """
    Test a line with multiple segments: (0,0)->(10,0)->(10,10).
    The total length is 20. 
    If spacing=5, we expect each segment to produce points.
    """
    spacing = 5.0
    result = discretize_line_with_normal_vector(
        gdf_lines=multi_segment_line_gdf, 
        discretization_distance=spacing
    )
    # Segment 1 length = 10, segment 2 length = 10 => total 2 segments
    # For each segment, we expect (10 / 5) + 1 = 3 points => 6 points total
    # But the code won't necessarily "merge" the final point of segment 1 
    # with the first point of segment 2. They might produce 1 duplicate 
    # at the junction. We can allow +1 difference in total:
    expected_per_segment = int(np.ceil(10.0 / spacing)) + 1  # 3
    expected_points = 2 * expected_per_segment  # 6
    # Let's allow for duplicates or rounding
    assert len(result) in {6, 7}, "Expected 6 or 7 points for two segments of length 10"

    # We can also check sub_idx col is correct
    # sub_idx typically 0 for the linestring, 
    # but if code enumerates segments differently, sub_idx might remain 0?
    # We'll just check that sub_idx exists:
    assert OutputConfig.SUB_IDX_COL in result.columns

def test_multi_line_string_gdf(multi_line_string_gdf):
    """
    Test a MultiLineString with two lines: (0,0)->(10,0) and (0,10)->(0,0).
    """
    result = discretize_line_with_normal_vector(multi_line_string_gdf, discretization_distance=2.5)
    # Each sub-line is length 10. With spacing=2.5, each line yields 5 points 
    # (0,2.5,5,7.5,10) + 1 => actually 5 points. So total 10 points from 2 lines.
    # But let's see if code merges last & first points or not. Usually it's 5 + 5=10.
    assert len(result) >= 10, "At least 10 points expected"

    # sub_idx should indicate the two lines
    #  - sub_idx=0 for line 1, sub_idx=1 for line 2
    unique_sub_idxs = set(result[OutputConfig.SUB_IDX_COL])
    assert len(unique_sub_idxs) == 2, "Should have exactly 2 sub_idx values in a MultiLineString"
    assert 0 in unique_sub_idxs and 1 in unique_sub_idxs, "sub_idx values should be 0 and 1"

def test_mix_lines_gdf(mix_lines_gdf):
    """
    Test a mixture of:
    1) line1: length=5
    2) line2: length=10
    3) mls:  two short lines
    4) degenerate line (0-length)
    """
    result = discretize_line_with_normal_vector(mix_lines_gdf, discretization_distance=1.0)

    # degenerate line => skip => 0 points from that geometry
    # line1 => length=5 => (0..5)/1.0 => 6 points
    # line2 => length=10 => 11 points
    # MLS => 
    #    sub-line1 => length sqrt( (1->2)^2 + (1->2)^2 ) = ~1.414 => maybe 2 points
    #    sub-line2 => length=1 => maybe 2 points 
    # total from MLS ~4
    # sum => 6 + 11 + 4 = 21 points
    # let's see if the code might produce +1 duplicates
    assert len(result) >= 21, f"Should produce at least 21 points, but got {len(result)}"

    # Check that the degenerate line was indeed skipped
    # The row_idx for that line might not appear in the results
    degenerate_idx = 3
    # Make sure it's not in row_idx col
    row_idxs_in_result = set(result[OutputConfig.ROW_IDX_COL])
    # Because the code might skip that line
    assert degenerate_idx not in row_idxs_in_result, "Degenerate line should have been skipped."

def test_columns_in_output(simple_line_gdf):
    """
    Check that the expected columns are always present in the output.
    """
    spacing = 1.0
    result = discretize_line_with_normal_vector(simple_line_gdf, discretization_distance=spacing)
    expected_cols = {
        OutputConfig.ROW_IDX_COL, 
        OutputConfig.SUB_IDX_COL, 
        OutputConfig.CHAINAGE_COL,
        OutputConfig.NORMAL_X_COL,
        OutputConfig.NORMAL_Y_COL,
        "geometry",
    }
    missing = expected_cols - set(result.columns)
    assert not missing, f"Missing columns: {missing}"

def test_crs_preserved(simple_line_gdf):
    """
    Check that the output GDF has the same CRS as the input GDF.
    """
    result = discretize_line_with_normal_vector(simple_line_gdf)
    assert result.crs == simple_line_gdf.crs, "CRS should be the same as input"

@pytest.mark.parametrize("threshold", [0.1, 0.5, 2.0])
def test_line_length_threshold(mix_lines_gdf, threshold):
    """
    Parametrized test to ensure that short segments are skipped if 
    line_length_threshold is bigger than segment length.
    """
    result = discretize_line_with_normal_vector(
        mix_lines_gdf, 
        line_length_threshold=threshold,
        discretization_distance=1.0,
    )
    # If threshold is large, short segments (like 1.414 or 1.0) are skipped
    # If threshold=2.0 => sub-line1 is 1.414 => skip, sub-line2 is 1 => skip
    # So we can test the row_idx col or sub_idx col to see if those sublines appear.
    # Example check:
    if threshold >= 2.0:
        # sub-lines with length <2 are skipped => check if fewer points
        # We had ~21 total points in test_mix_lines_gdf, but skipping might 
        # reduce that by 4 => ~17 or fewer
        assert len(result) < 21, "With threshold >=2.0, short sublines must be skipped"
    else:
        assert len(result) >= 21, "With threshold <2.0, short sublines should remain"

def test_point_normals_direction(simple_line_gdf):
    """
    Optional: Check that normal vectors are correct for a horizontal line.
    (0,0)->(10,0) => dx=10, dy=0 => normal ~ (0, +1) or (0, -1) depending on sign
    """
    result = discretize_line_with_normal_vector(simple_line_gdf, discretization_distance=5.0)
    # For a horizontal line from left to right,
    # the direction is +x, so the normal is either up or down in y
    # The code uses nx = -dy/mag => = 0, ny= dx/mag => = +1 
    # So normal_x ~ 0.0, normal_y ~ +1.0
    unique_norms = set(
        (round(nx, 3), round(ny, 3)) 
        for nx, ny in zip(result[OutputConfig.NORMAL_X_COL], result[OutputConfig.NORMAL_Y_COL])
    )
    # Expect all normals ~ (0,1)
    # We allow a small rounding difference
    for (nx, ny) in unique_norms:
        assert abs(nx) < 1e-3, f"Expected normal_x near 0. Got {nx}"
        # we typically expect ny ~ 1 or -1
        # depends on your code sign. Let's assume it's +1
        assert abs(abs(ny) - 1.0) < 1e-3, f"Expected normal_y near +/-1. Got {ny}"
