



##############################################################################
#                      SAMPLE DEM AT (x,y)                                  #
##############################################################################

def sample_dem_for_xy(dataset, x, y):
    """
    Reads 1x1 pixel from 'dataset' at (x,y). Return NAN if out-of-bounds.
    """
    transform = dataset.transform
    px_size_x = transform.a
    px_size_y = -transform.e
    origin_x = transform.c
    origin_y = transform.f

    col = int(math.floor((x - origin_x) / px_size_x))
    row = int(math.floor((origin_y - y) / px_size_y))

    try:
        window = Window(col_off=col, row_off=row, width=1, height=1)
        data = dataset.read(1, window=window)
        return float(data[0, 0])
    except:
        return np.nan



def compute_longitudinal_slope(
    gdf_points,
    row_idx_col="row_idx",
    sub_idx_col="sub_idx",
    chainage_col="chainage",
    output_col="slope_longitudinal"
):
    """
    Group by (row_idx, sub_idx), sort by chainage, compute slope for consecutive points:
       slope_i = (z_center[i+1] - z_center[i]) / (chainage[i+1] - chainage[i])
    If you prefer Euclidean distance, replace chainage with geometry distance.
    We'll store the slope at point i or i+1. (Here we store it at i.)

    This modifies gdf_points in-place, so the indexing must be consistent.
    We can create a new column with NaN for the last point in each group.
    """
    logging.info("Computing longitudinal slope among consecutive points...")

    # We'll store the slope in an array aligned with gdf_points
    slope_vals = [np.nan] * len(gdf_points)

    # group by row_idx, sub_idx
    grouped = gdf_points.groupby([row_idx_col, sub_idx_col], group_keys=False)
    for (r_i, s_i), group_df in grouped:
        # sort by chainage
        group_sorted = group_df.sort_values(chainage_col)
        indices = group_sorted.index.tolist()
        for i in range(len(indices) - 1):
            idx_i = indices[i]
            idx_j = indices[i+1]
            z_i = group_sorted.loc[idx_i, "z_center"]
            z_j = group_sorted.loc[idx_j, "z_center"]
            dist_i = group_sorted.loc[idx_i, chainage_col]
            dist_j = group_sorted.loc[idx_j, chainage_col]

            if (not math.isnan(z_i)) and (not math.isnan(z_j)):
                denom = dist_j - dist_i
                if abs(denom) > 1e-9:
                    slope_ij = (z_j - z_i) / denom
                else:
                    slope_ij = np.nan
            else:
                slope_ij = np.nan

            slope_vals[idx_i] = slope_ij

    gdf_points[output_col] = slope_vals
    return gdf_points







import numpy as np
from numba import cuda

@cuda.jit
def calculate_slopes_kernel(distances, elevations, slopes, segment_size, threshold, valid_segments):
    """
    CUDA kernel to calculate slopes for each segment.
    """
    idx = cuda.grid(1)
    n_points = len(distances)

    if idx < n_points - 1:
        start_idx = idx * segment_size
        end_idx = min(start_idx + segment_size, n_points)

        # Ensure there are enough points in the segment
        if end_idx - start_idx < 2:
            valid_segments[idx] = 0
            return

        local_slopes = []
        for i in range(start_idx, end_idx - 1):
            dx = distances[i + 1] - distances[i]
            dz = elevations[i + 1] - elevations[i]
            if dx != 0:
                local_slopes.append(dz / dx)

        # Check variability within the segment
        if len(local_slopes) > 0:
            mean_slope = np.mean(local_slopes)
            max_variation = max(abs(s - mean_slope) for s in local_slopes)
            if max_variation < threshold:
                slopes[idx] = mean_slope
                valid_segments[idx] = 1
            else:
                valid_segments[idx] = 0
        else:
            valid_segments[idx] = 0

def segment_slope_analysis(distances, elevations, segment_size=5, threshold=0.5):
    """
    Main function to calculate slopes using segment validation with CUDA.
    """
    n_points = len(distances)
    n_segments = n_points // segment_size

    # Allocate GPU memory
    d_distances = cuda.to_device(distances)
    d_elevations = cuda.to_device(elevations)
    d_slopes = cuda.device_array(n_segments, dtype=np.float32)
    d_valid_segments = cuda.device_array(n_segments, dtype=np.int32)

    # Define CUDA grid/block size
    threads_per_block = 256
    blocks = (n_segments + threads_per_block - 1) // threads_per_block

    # Launch kernel
    calculate_slopes_kernel[blocks, threads_per_block](
        d_distances, d_elevations, d_slopes, segment_size, threshold, d_valid_segments
    )

    # Copy results back to host
    slopes = d_slopes.copy_to_host()
    valid_segments = d_valid_segments.copy_to_host()

    # Filter and return valid slopes
    return slopes[valid_segments == 1]

# Example usage
distances = np.array([0, 5, 10, 15, 20, 25, 30], dtype=np.float32)
elevations = np.array([100, 102, 105, 107, 110, 112, 115], dtype=np.float32)

segment_size = 3
threshold = 0.5

# Calculate slopes using GPU
valid_slopes = segment_slope_analysis(distances, elevations, segment_size, threshold)

print("Valid slopes:", valid_slopes)
